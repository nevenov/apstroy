<?php $__env->startSection('content'); ?>

    <!-- banner -->
    <div class="inside-banner">
        <div class="container">
            <span class="pull-right"><a href="<?php echo e(route('Home')); ?>"><i class="fa fa-home"></i></a> /
                <?php if(@$WebmasterSection!="none"): ?>
                    <?php echo trans('backLang.'.$WebmasterSection->name); ?>

                <?php elseif(@$search_word!=""): ?>
                    <?php echo e(@$search_word); ?>

                <?php else: ?>
                    <?php echo e($User->name); ?>

                <?php endif; ?>
            </span>
            <h2>
                <?php if(@$search_word!=""): ?>
                    <?php echo e(@$search_word); ?>

                <?php elseif($CurrentCategory!="none"): ?>
                    <?php if(!empty($CurrentCategory)): ?>
                        <?php
                        $category_title_var = "title_" . trans('backLang.boxCode');
                        ?>
                        <?php echo e($CurrentCategory->$category_title_var); ?>

                    <?php elseif(@$WebmasterSection!="none"): ?>
                        <?php echo trans('backLang.'.$WebmasterSection->name); ?>

                    <?php elseif(@$search_word!=""): ?>
                        <?php echo e(@$search_word); ?>

                    <?php else: ?>
                        <?php echo e($User->name); ?>

                    <?php endif; ?>
                <?php endif; ?>
            </h2>
        </div>
    </div>
    <!-- banner -->

    <div class="container">
        <div class="listing spacer">

        <?php
            $countCategories = count($Categories);
            //$countCategories = 0;
            ?>


            <div class="row">
                <?php if($countCategories>0): ?>
                    <?php echo $__env->make('frontEnd.includes.side', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endif; ?>
                <div class="col-lg-<?php echo e(($countCategories>0)? "9":"12"); ?>">
                    <?php if($Topics->total() == 0): ?>
                        <div class="alert alert-warning">
                            <i class="fa fa-info"></i> &nbsp; <?php echo e(trans('frontLang.noData')); ?>

                        </div>
                    <?php else: ?>
                        <div class="row">
                            <?php if($Topics->total() > 0): ?>

                                <?php
                                $title_var = "title_" . trans('backLang.boxCode');
                                $title_var2 = "title_" . trans('backLang.boxCodeOther');
                                $details_var = "details_" . trans('backLang.boxCode');
                                $details_var2 = "details_" . trans('backLang.boxCodeOther');
                                $slug_var = "seo_url_slug_" . trans('backLang.boxCode');
                                $slug_var2 = "seo_url_slug_" . trans('backLang.boxCodeOther');
                                $i = 0;
                                ?>
                                <?php $__currentLoopData = $Topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    if ($Topic->$title_var != "") {
                                        $title = $Topic->$title_var;
                                    } else {
                                        $title = $Topic->$title_var2;
                                    }
                                    if ($Topic->$details_var != "") {
                                        $details = $details_var;
                                    } else {
                                        $details = $details_var2;
                                    }
                                    $section = "";
                                    try {
                                        if ($Topic->section->$title_var != "") {
                                            $section = $Topic->section->$title_var;
                                        } else {
                                            $section = $Topic->section->$title_var2;
                                        }
                                    } catch (Exception $e) {
                                        $section = "";
                                    }

                                    // set row div
                                    if (($i == 2 && $countCategories > 0) || ($i == 3 && $countCategories == 0)) {
                                        $i = 0;
                                        echo "</div><div class='row'>";
                                    }
                                    if ($Topic->$slug_var != "" && Helper::GeneralWebmasterSettings("links_status")) {
                                        if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
                                            $topic_link_url = url(trans('backLang.code') . "/" . $Topic->$slug_var);
                                        } else {
                                            $topic_link_url = url($Topic->$slug_var);
                                        }
                                    } else {
                                        if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
                                            $topic_link_url = route('FrontendTopicByLang', ["lang" => trans('backLang.code'), "section" => $Topic->webmasterSection->name, "id" => $Topic->id]);
                                        } else {
                                            $topic_link_url = route('FrontendTopic', ["section" => $Topic->webmasterSection->name, "id" => $Topic->id]);
                                        }
                                    }
                                    ?>
                                    <div class="col-lg-<?php echo e(($countCategories>0)? "6":"4"); ?>">
                                        <div class="item">
                                            <div class="image-holder">
                                                <?php if($Topic->webmasterSection->type==2 && $Topic->video_file!=""): ?>
                                                    <?php if($Topic->video_type ==1): ?>
                                                        <?php
                                                        $Youtube_id = Helper::Get_youtube_video_id($Topic->video_file);
                                                        ?>
                                                        <?php if($Youtube_id !=""): ?>
                                                            
                                                            <a class="video-popup"
                                                               href="https://www.youtube.com/watch?v=<?php echo e($Youtube_id); ?>"
                                                               title="<?php echo e($title); ?>">
                                                                <img src="https://img.youtube.com/vi/<?php echo e($Youtube_id); ?>/0.jpg"
                                                                     alt="<?php echo e($title); ?>"/>
                                                            </a>
                                                        <?php endif; ?>
                                                    <?php elseif($Topic->video_type ==2): ?>
                                                        <?php
                                                        $Vimeo_id = Helper::Get_vimeo_video_id($Topic->video_file);
                                                        ?>
                                                        <?php if($Vimeo_id !=""): ?>
                                                            
                                                            <?php
                                                            $data = file_get_contents("http://vimeo.com/api/v2/video/$Vimeo_id.json");
                                                            $data = json_decode($data);
                                                            ?>
                                                            <a class="video-popup"
                                                               href="http://vimeo.com/<?php echo e($Vimeo_id); ?>"
                                                               title="<?php echo e($title); ?>">
                                                                <img src="<?php echo e($data[0]->thumbnail_medium); ?>"
                                                                     alt="<?php echo e($title); ?>"/>
                                                            </a>
                                                        <?php endif; ?>

                                                    <?php elseif($Topic->video_type ==3): ?>
                                                        <a href="<?php echo e($topic_link_url); ?>">
                                                            <?php if($Topic->photo_file !=""): ?>
                                                                <img src="<?php echo e(URL::to('uploads/topics/'.$Topic->photo_file)); ?>"
                                                                     alt="<?php echo e($title); ?>"/>
                                                            <?php endif; ?>
                                                        </a>
                                                    <?php else: ?>
                                                        <a class="video-popup"
                                                           href="<?php echo e(URL::to('uploads/topics/'.$Topic->video_file)); ?>"
                                                           title="<?php echo e($title); ?>">
                                                            <?php if($Topic->photo_file !=""): ?>
                                                                <img src="<?php echo e(URL::to('uploads/topics/'.$Topic->photo_file)); ?>"
                                                                     alt="<?php echo e($title); ?>"/>
                                                            <?php endif; ?>
                                                        </a>
                                                    <?php endif; ?>

                                                <?php elseif($Topic->webmasterSection->type==3 && $Topic->audio_file!=""): ?>
                                                    <?php if($Topic->photo_file !=""): ?>
                                                        <img src="<?php echo e(URL::to('uploads/topics/'.$Topic->photo_file)); ?>"
                                                             alt="<?php echo e($title); ?>"/>
                                                    <?php else: ?>
                                                        <div dir="ltr">
                                                            <audio src="<?php echo e(URL::to('uploads/topics/'.$Topic->audio_file)); ?>"
                                                                   preload="auto" controls></audio>
                                                            <br><br>

                                                        </div>
                                                    <?php endif; ?>
                                                <?php elseif(count($Topic->photos)>0): ?>
                                                    <a href="<?php echo e($topic_link_url); ?>">
                                                        <?php if($Topic->photo_file !=""): ?>
                                                            <img src="<?php echo e(URL::to('uploads/topics/'.$Topic->photo_file)); ?>"
                                                                 alt="<?php echo e($title); ?>"/>
                                                        <?php else: ?>
                                                            <img src="<?php echo e(URL::to('uploads/topics/'.$Topic->photos[0]->file)); ?>"
                                                                 alt="<?php echo e($Topic->photos[0]->title); ?>"/>
                                                        <?php endif; ?>
                                                    </a>
                                                <?php else: ?>
                                                    <a href="<?php echo e($topic_link_url); ?>">
                                                        <?php if($Topic->photo_file !=""): ?>
                                                            <img src="<?php echo e(URL::to('uploads/topics/'.$Topic->photo_file)); ?>"
                                                                 alt="<?php echo e($title); ?>"/>
                                                        <?php endif; ?>
                                                    </a>
                                                <?php endif; ?>


                                                <div class="status visits"><i
                                                            class="fa fa-eye"></i> <?php echo e(trans('frontLang.visits')); ?>

                                                    : <?php echo $Topic->visits; ?></div>
                                                <?php if($Topic->webmasterSection->comments_status): ?>
                                                    <div class="status comments"><i
                                                                class="fa fa-comments"></i> <?php echo e(trans('frontLang.comments')); ?>

                                                        : <?php echo e(count($Topic->approvedComments)); ?></div>
                                                <?php else: ?>
                                                    <div class="status comments"><i
                                                                class="fa fa-user"></i> <?php echo e($Topic->user->name); ?>

                                                    </div>
                                                <?php endif; ?>

                                            </div>
                                            <h4>
                                                <a href="<?php echo e($topic_link_url); ?>">
                                                    <?php if($Topic->icon !=""): ?>
                                                        <i class="fa <?php echo $Topic->icon; ?> "></i>&nbsp;
                                                    <?php endif; ?>
                                                    <?php echo e($title); ?>

                                                </a>
                                            </h4>

                                            
                                            <?php if(count($Topic->webmasterSection->customFields) >0): ?>
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="col-lg-12 fields">
                                                            <?php
                                                            $cf_title_var = "title_" . trans('backLang.boxCode');
                                                            $cf_title_var2 = "title_" . trans('backLang.boxCodeOther');
                                                            ?>
                                                            <?php $__currentLoopData = $Topic->webmasterSection->customFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customField): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php
                                                                if ($customField->$cf_title_var != "") {
                                                                    $cf_title = $customField->$cf_title_var;
                                                                } else {
                                                                    $cf_title = $customField->$cf_title_var2;
                                                                }


                                                                $cf_saved_val = "";
                                                                $cf_saved_val_array = array();
                                                                if (count($Topic->fields) > 0) {
                                                                    foreach ($Topic->fields as $t_field) {
                                                                        if ($t_field->field_id == $customField->id) {
                                                                            if ($customField->type == 7) {
                                                                                // if multi check
                                                                                $cf_saved_val_array = explode(", ", $t_field->field_value);
                                                                            } else {
                                                                                $cf_saved_val = $t_field->field_value;
                                                                            }
                                                                        }
                                                                    }
                                                                }

                                                                ?>

                                                                <?php if(($cf_saved_val!="" || count($cf_saved_val_array) > 0) && ($customField->lang_code == "all" || $customField->lang_code == trans('backLang.boxCode'))): ?>
                                                                    <?php if($customField->type ==12): ?>
                                                                        
                                                                    <?php elseif($customField->type ==11): ?>
                                                                        
                                                                    <?php elseif($customField->type ==10): ?>
                                                                        
                                                                    <?php elseif($customField->type ==9): ?>
                                                                        
                                                                    <?php elseif($customField->type ==8): ?>
                                                                        
                                                                    <?php elseif($customField->type ==7): ?>
                                                                        
                                                                    <?php elseif($customField->type ==6): ?>
                                                                        
                                                                        <div class="row field-row">
                                                                            <div class="col-lg-4">
                                                                                <?php echo $cf_title; ?> :
                                                                            </div>
                                                                            <div class="col-lg-8">
                                                                                <?php
                                                                                $cf_details_var = "details_" . trans('backLang.boxCode');
                                                                                $cf_details_var2 = "details_en" . trans('backLang.boxCodeOther');
                                                                                if ($customField->$cf_details_var != "") {
                                                                                    $cf_details = $customField->$cf_details_var;
                                                                                } else {
                                                                                    $cf_details = $customField->$cf_details_var2;
                                                                                }
                                                                                $cf_details_lines = preg_split('/\r\n|[\r\n]/', $cf_details);
                                                                                $line_num = 1;
                                                                                ?>
                                                                                <?php $__currentLoopData = $cf_details_lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cf_details_line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <?php if($line_num == $cf_saved_val): ?>
                                                                                        <?php echo $cf_details_line; ?>

                                                                                    <?php endif; ?>
                                                                                    <?php
                                                                                    $line_num++;
                                                                                    ?>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </div>
                                                                        </div>
                                                                    <?php elseif($customField->type ==5): ?>
                                                                        
                                                                        <div class="row field-row">
                                                                            <div class="col-lg-4">
                                                                                <?php echo $cf_title; ?> :
                                                                            </div>
                                                                            <div class="col-lg-8">
                                                                                <?php echo date('Y-m-d H:i:s', strtotime($cf_saved_val)); ?>

                                                                            </div>
                                                                        </div>
                                                                    <?php elseif($customField->type ==4): ?>
                                                                        
                                                                        <div class="row field-row">
                                                                            <div class="col-lg-4">
                                                                                <?php echo $cf_title; ?> :
                                                                            </div>
                                                                            <div class="col-lg-8">
                                                                                <?php echo date('Y-m-d', strtotime($cf_saved_val)); ?>

                                                                            </div>
                                                                        </div>
                                                                    <?php elseif($customField->type ==3): ?>
                                                                        
                                                                        <div class="row field-row">
                                                                            <div class="col-lg-4">
                                                                                <?php echo $cf_title; ?> :
                                                                            </div>
                                                                            <div class="col-lg-8">
                                                                                <?php echo $cf_saved_val; ?>

                                                                            </div>
                                                                        </div>
                                                                    <?php elseif($customField->type ==2): ?>
                                                                        
                                                                        <div class="row field-row">
                                                                            <div class="col-lg-4">
                                                                                <?php echo $cf_title; ?> :
                                                                            </div>
                                                                            <div class="col-lg-8">
                                                                                <?php echo $cf_saved_val; ?>

                                                                            </div>
                                                                        </div>
                                                                    <?php elseif($customField->type ==1): ?>
                                                                        
                                                                    <?php else: ?>
                                                                        
                                                                        <div class="row field-row">
                                                                            <div class="col-lg-4">
                                                                                <?php echo $cf_title; ?> :
                                                                            </div>
                                                                            <div class="col-lg-8">
                                                                                <?php echo $cf_saved_val; ?>

                                                                            </div>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            

                                            <?php if(strip_tags($Topic->$details) !=""): ?>
                                                <p>
                                                    <?php if($Topic->webmasterSection->date_status): ?>
                                                        <strong><i class="fa fa-calendar"></i> <?php echo $Topic->date; ?>,
                                                        </strong>
                                                    <?php endif; ?>
                                                    <?php echo e(str_limit(strip_tags($Topic->$details), $limit = 200, $end = '...')); ?>



                                                </p>
                                                <a href="<?php echo e($topic_link_url); ?>"
                                                   class="btn btn-primary"><?php echo e(trans('frontLang.readMore')); ?></a>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <?php
                                    $i++;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                        <div class="row">
                            <div class="col-lg-8">
                                <?php echo $Topics->links(); ?>

                            </div>
                            <div class="col-lg-4 text-right">
                                <br>
                                <small><?php echo e($Topics->firstItem()); ?> - <?php echo e($Topics->lastItem()); ?> <?php echo e(trans('backLang.of')); ?>

                                    ( <?php echo e($Topics->total()); ?> ) <?php echo e(trans('backLang.records')); ?></small>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>