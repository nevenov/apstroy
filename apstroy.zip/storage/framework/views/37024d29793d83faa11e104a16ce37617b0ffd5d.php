<?php $__env->startSection('content'); ?>

    <!-- start Home Slider -->
    <?php echo $__env->make('frontEnd.includes.slider', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- end Home Slider -->



    <div class="banner-search">
        <div class="container">
            <!-- banner -->
            <div class="searchbar">
                <div class="row">
                    <div class="col-lg-<?php echo e((count($TextBanners) ==2)? "4":"3"); ?>">
                        <?php echo e(Form::open(['route'=>['searchTopics'],'method'=>'POST','class'=>'form-search'])); ?>

                        <div class="row">
                            <div class="col-lg-12">
                                <h3><i class="fa fa-search"></i> <?php echo e(trans('backLang.search')); ?></h3>
                            </div>
                            <div class="col-lg-12 col-sm-12 ">
                                <?php echo e(Form::open(['route'=>['searchTopics'],'method'=>'POST','class'=>'form-search'])); ?>

                                <div class="input-group">
                                    <?php echo Form::text('search_word',@$search_word, array('placeholder' => trans('frontLang.search'),'class' => 'form-control','id'=>'search_word','required'=>'')); ?>

                                    <span class="input-group-btn">
                    <button type="submit" class="btn btn-theme"><i
                                class="fa fa-search"></i> <?php echo e(trans('backLang.search')); ?></button>
                </span>
                                </div>
                            </div>
                        </div>
                        <?php echo e(Form::close()); ?>


                    </div>
                        <?php if(count($TextBanners)>0): ?>
                            <?php $__currentLoopData = $TextBanners->slice(0,1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $TextBanner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                try {
                                    $TextBanner_type = $TextBanner->webmasterBanner->type;
                                } catch (Exception $e) {
                                    $TextBanner_type = 0;
                                }
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $title_var = "title_" . trans('backLang.boxCode');
                            $details_var = "details_" . trans('backLang.boxCode');
                            $file_var = "file_" . trans('backLang.boxCode');

                            $col_width = 12;
                            if (count($TextBanners) == 2) {
                                $col_width = 4;
                            }
                            if (count($TextBanners) == 3) {
                                $col_width = 3;
                            }
                            if (count($TextBanners) > 3) {
                                $col_width = 3;
                            }
                            ?>
                                    <?php $__currentLoopData = $TextBanners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $TextBanner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-lg-<?php echo e($col_width); ?>">
                                            <div class="box">
                                                <div class="aligncenter">
                                                    <?php if($TextBanner->code !=""): ?>
                                                        <?php echo $TextBanner->code; ?>

                                                    <?php else: ?>
                                                        <?php if($TextBanner->$file_var !=""): ?>
                                                            <img src="<?php echo e(URL::to('uploads/banners/'.$TextBanner->$file_var)); ?>"
                                                                 alt="<?php echo e($TextBanner->$title_var); ?>"/>
                                                        <?php endif; ?>
                                                        <h3>
                                                            <?php if($TextBanner->icon !=""): ?>
                                                                <i class="fa <?php echo e($TextBanner->icon); ?>"></i>
                                                            <?php endif; ?>
                                                            <?php echo $TextBanner->$title_var; ?></h3>
                                                        <p>
                                                            <?php if($TextBanner->$details_var !=""): ?>
                                                                <?php echo nl2br($TextBanner->$details_var); ?>

                                                            <?php endif; ?>

                                                            <?php if($TextBanner->link_url !=""): ?>
                                                                <br><a href="<?php echo $TextBanner->link_url; ?>"><?php echo e(trans('frontLang.moreDetails')); ?></a>
                                                            <?php endif; ?>
                                                        </p>
                                                    <?php endif; ?>

                                                </div>

                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
    <!-- banner -->
    <div class="container">
        <?php if(count($HomeTopics)>0): ?>
            <?php
            $title_var = "title_" . trans('backLang.boxCode');
            $title_var2 = "title_" . trans('backLang.boxCodeOther');
            $details_var = "details_" . trans('backLang.boxCode');
            $details_var2 = "details_" . trans('backLang.boxCodeOther');
            $slug_var = "seo_url_slug_" . trans('backLang.boxCode');
            $slug_var2 = "seo_url_slug_" . trans('backLang.boxCodeOther');
            $section_url = "";
            ?>
            <?php $__currentLoopData = $HomeTopics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $HomeTopic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                if ($HomeTopic->webmasterSection->$slug_var != "" && Helper::GeneralWebmasterSettings("links_status")) {
                    if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
                        $section_url = url(trans('backLang.code') . "/" . $HomeTopic->webmasterSection->$slug_var);
                    } else {
                        $section_url = url($HomeTopic->webmasterSection->$slug_var);
                    }
                } else {
                    if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
                        $section_url = url(trans('backLang.code') . "/" . $HomeTopic->webmasterSection->name);
                    } else {
                        $section_url = url($HomeTopic->webmasterSection->name);
                    }
                }
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="listing spacer"><a href="<?php echo e(url($section_url)); ?>"
                                           class="pull-right viewall"><?php echo e(trans('frontLang.viewMore')); ?></a>
                <h2><?php echo e(trans('frontLang.homeContents1Title')); ?></h2>
                <div id="owl-example" class="owl-carousel owl-theme">
                    <?php $__currentLoopData = $HomeTopics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $HomeTopic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        if ($HomeTopic->$title_var != "") {
                            $title = $HomeTopic->$title_var;
                        } else {
                            $title = $HomeTopic->$title_var2;
                        }
                        if ($HomeTopic->$details_var != "") {
                            $details = $details_var;
                        } else {
                            $details = $details_var2;
                        }

                        if ($HomeTopic->$slug_var != "" && Helper::GeneralWebmasterSettings("links_status")) {
                            if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
                                $topic_link_url = url(trans('backLang.code') . "/" . $HomeTopic->$slug_var);
                            } else {
                                $topic_link_url = url($HomeTopic->$slug_var);
                            }
                        } else {
                            if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
                                $topic_link_url = route('FrontendTopicByLang', ["lang" => trans('backLang.code'), "section" => $HomeTopic->webmasterSection->name, "id" => $HomeTopic->id]);
                            } else {
                                $topic_link_url = route('FrontendTopic', ["section" => $HomeTopic->webmasterSection->name, "id" => $HomeTopic->id]);
                            }
                        }

                        ?>
                        <div class="item">
                            <div class="image-holder">
                                <a href="<?php echo e($topic_link_url); ?>">
                                    <?php if($HomeTopic->webmasterSection->type==2 && $HomeTopic->video_file!=""): ?>
                                        <?php if($HomeTopic->video_type ==1): ?>
                                            <?php
                                            $Youtube_id = Helper::Get_youtube_video_id($HomeTopic->video_file);
                                            ?>
                                            <?php if($Youtube_id !=""): ?>
                                                
                                                <img src="https://img.youtube.com/vi/<?php echo e($Youtube_id); ?>/0.jpg"
                                                     alt="<?php echo e($title); ?>"/>
                                            <?php endif; ?>
                                        <?php elseif($HomeTopic->video_type ==2): ?>
                                            <?php
                                            $Vimeo_id = Helper::Get_vimeo_video_id($HomeTopic->video_file);
                                            ?>
                                            <?php if($Vimeo_id !=""): ?>
                                                
                                                <?php
                                                $data = file_get_contents("http://vimeo.com/api/v2/video/$id.json");
                                                $data = json_decode($data);
                                                ?>
                                                <img src="<?php echo e($data[0]->thumbnail_medium); ?>"
                                                     alt="<?php echo e($title); ?>"/>
                                            <?php endif; ?>

                                        <?php elseif($HomeTopic->video_type ==3): ?>
                                            <?php if($HomeTopic->photo_file !=""): ?>
                                                <img src="<?php echo e(URL::to('uploads/topics/'.$HomeTopic->photo_file)); ?>"
                                                     alt="<?php echo e($title); ?>"/>
                                            <?php endif; ?>

                                        <?php else: ?>
                                            <?php if($HomeTopic->photo_file !=""): ?>
                                                <img src="<?php echo e(URL::to('uploads/topics/'.$HomeTopic->photo_file)); ?>"
                                                     alt="<?php echo e($title); ?>"/>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                    <?php elseif($HomeTopic->webmasterSection->type==3 && $HomeTopic->audio_file!=""): ?>
                                        <?php if($HomeTopic->photo_file !=""): ?>
                                            <img src="<?php echo e(URL::to('uploads/topics/'.$HomeTopic->photo_file)); ?>"
                                                 alt="<?php echo e($title); ?>"/>
                                        <?php else: ?>
                                            <div>
                                                <br>
                                                <audio controls>
                                                    <source src="<?php echo e(URL::to('uploads/topics/'.$HomeTopic->audio_file)); ?>"
                                                            type="audio/mpeg">
                                                    Your browser does not support the audio element.
                                                </audio>
                                                <br><br><br>

                                            </div>
                                        <?php endif; ?>
                                    <?php elseif(count($HomeTopic->photos)>0): ?>
                                        <?php if($HomeTopic->photo_file !=""): ?>
                                            <img src="<?php echo e(URL::to('uploads/topics/'.$HomeTopic->photo_file)); ?>"
                                                 alt="<?php echo e($title); ?>"/>
                                        <?php else: ?>
                                            <img src="<?php echo e(URL::to('uploads/topics/'.$HomeTopic->photos[0]->file)); ?>"
                                                 alt="<?php echo e($HomeTopic->photos[0]->title); ?>"/>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if($HomeTopic->photo_file !=""): ?>
                                            <img src="<?php echo e(URL::to('uploads/topics/'.$HomeTopic->photo_file)); ?>"
                                                 alt="<?php echo e($title); ?>"/>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </a>
                                <div class="status visits"><i
                                            class="fa fa-eye"></i> <?php echo e(trans('frontLang.visits')); ?>

                                    : <?php echo $HomeTopic->visits; ?></div>
                                <?php if($HomeTopic->webmasterSection->comments_status): ?>
                                    <div class="status comments"><i
                                                class="fa fa-comments"></i> <?php echo e(trans('frontLang.comments')); ?>

                                        : <?php echo e(count($HomeTopic->approvedComments)); ?></div>
                                <?php else: ?>
                                    <div class="status comments"><i
                                                class="fa fa-user"></i> <?php echo e($HomeTopic->user->name); ?> </div>
                                <?php endif; ?>

                            </div>
                            <h4>
                                <a href="<?php echo e($topic_link_url); ?>">
                                    <?php if($HomeTopic->icon !=""): ?>
                                        <i class="fa <?php echo $HomeTopic->icon; ?> "></i>&nbsp;
                                    <?php endif; ?>
                                    <?php echo e($title); ?>

                                </a>
                            </h4>

                            
                            <?php if(count($HomeTopic->webmasterSection->customFields) >0): ?>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="col-lg-12 fields">
                                            <?php
                                            $cf_title_var = "title_" . trans('backLang.boxCode');
                                            $cf_title_var2 = "title_" . trans('backLang.boxCodeOther');
                                            ?>
                                            <?php $__currentLoopData = $HomeTopic->webmasterSection->customFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customField): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                if ($customField->$cf_title_var != "") {
                                                    $cf_title = $customField->$cf_title_var;
                                                } else {
                                                    $cf_title = $customField->$cf_title_var2;
                                                }


                                                $cf_saved_val = "";
                                                $cf_saved_val_array = array();
                                                if (count($HomeTopic->fields) > 0) {
                                                    foreach ($HomeTopic->fields as $t_field) {
                                                        if ($t_field->field_id == $customField->id) {
                                                            if ($customField->type == 7) {
                                                                // if multi check
                                                                $cf_saved_val_array = explode(", ", $t_field->field_value);
                                                            } else {
                                                                $cf_saved_val = $t_field->field_value;
                                                            }
                                                        }
                                                    }
                                                }

                                                ?>

                                                <?php if(($cf_saved_val!="" || count($cf_saved_val_array) > 0) && ($customField->lang_code == "all" || $customField->lang_code == trans('backLang.boxCode'))): ?>
                                                    <?php if($customField->type ==12): ?>
                                                        
                                                    <?php elseif($customField->type ==11): ?>
                                                        
                                                    <?php elseif($customField->type ==10): ?>
                                                        
                                                    <?php elseif($customField->type ==9): ?>
                                                        
                                                    <?php elseif($customField->type ==8): ?>
                                                        
                                                    <?php elseif($customField->type ==7): ?>
                                                        
                                                    <?php elseif($customField->type ==6): ?>
                                                        
                                                        <div class="row field-row">
                                                            <div class="col-lg-4">
                                                                <?php echo $cf_title; ?> :
                                                            </div>
                                                            <div class="col-lg-8">
                                                                <?php
                                                                $cf_details_var = "details_" . trans('backLang.boxCode');
                                                                $cf_details_var2 = "details_en" . trans('backLang.boxCodeOther');
                                                                if ($customField->$cf_details_var != "") {
                                                                    $cf_details = $customField->$cf_details_var;
                                                                } else {
                                                                    $cf_details = $customField->$cf_details_var2;
                                                                }
                                                                $cf_details_lines = preg_split('/\r\n|[\r\n]/', $cf_details);
                                                                $line_num = 1;
                                                                ?>
                                                                <?php $__currentLoopData = $cf_details_lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cf_details_line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($line_num == $cf_saved_val): ?>
                                                                        <?php echo $cf_details_line; ?>

                                                                    <?php endif; ?>
                                                                    <?php
                                                                    $line_num++;
                                                                    ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </div>
                                                        </div>
                                                    <?php elseif($customField->type ==5): ?>
                                                        
                                                        <div class="row field-row">
                                                            <div class="col-lg-4">
                                                                <?php echo $cf_title; ?> :
                                                            </div>
                                                            <div class="col-lg-8">
                                                                <?php echo date('Y-m-d H:i:s', strtotime($cf_saved_val)); ?>

                                                            </div>
                                                        </div>
                                                    <?php elseif($customField->type ==4): ?>
                                                        
                                                        <div class="row field-row">
                                                            <div class="col-lg-4">
                                                                <?php echo $cf_title; ?> :
                                                            </div>
                                                            <div class="col-lg-8">
                                                                <?php echo date('Y-m-d', strtotime($cf_saved_val)); ?>

                                                            </div>
                                                        </div>
                                                    <?php elseif($customField->type ==3): ?>
                                                        
                                                        <div class="row field-row">
                                                            <div class="col-lg-4">
                                                                <?php echo $cf_title; ?> :
                                                            </div>
                                                            <div class="col-lg-8">
                                                                <?php echo $cf_saved_val; ?>

                                                            </div>
                                                        </div>
                                                    <?php elseif($customField->type ==2): ?>
                                                        
                                                        <div class="row field-row">
                                                            <div class="col-lg-4">
                                                                <?php echo $cf_title; ?> :
                                                            </div>
                                                            <div class="col-lg-8">
                                                                <?php echo $cf_saved_val; ?>

                                                            </div>
                                                        </div>
                                                    <?php elseif($customField->type ==1): ?>
                                                        
                                                    <?php else: ?>
                                                        
                                                        <div class="row field-row">
                                                            <div class="col-lg-4">
                                                                <?php echo $cf_title; ?> :
                                                            </div>
                                                            <div class="col-lg-8">
                                                                <?php echo $cf_saved_val; ?>

                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            

                            <?php if(strip_tags($HomeTopic->$details) !=""): ?>
                                <p>
                                    <?php echo e(str_limit(strip_tags($HomeTopic->$details), $limit = 100, $end = '...')); ?>

                                </p>
                            <?php endif; ?>
                            <a href="<?php echo e($topic_link_url); ?>"
                               class="btn btn-primary"><?php echo e(trans('frontLang.readMore')); ?></a>

                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>
        <div class="spacer">
            <div class="row">
                <?php
                $wdth_col = 12;
                if (count($HomePartners) > 0) {
                    $wdth_col = 8;
                }
                ?>
                <?php if(count($HomePhotos)>0): ?>
                    <div class="col-lg-<?php echo e($wdth_col); ?> recent-view">
                        <?php $__currentLoopData = $HomePhotos->slice(0, 1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $HomeTopic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            if ($HomeTopic->$title_var != "") {
                                $title = $HomeTopic->$title_var;
                            } else {
                                $title = $HomeTopic->$title_var2;
                            }
                            if ($HomeTopic->$details_var != "") {
                                $details = $details_var;
                            } else {
                                $details = $details_var2;
                            }
                            ?>
                            <h3>
                                <?php if($HomeTopic->icon !=""): ?>
                                    <i class="fa <?php echo $HomeTopic->icon; ?> "></i>&nbsp;
                                <?php endif; ?>
                                <?php echo e($title); ?>

                            </h3>

                            <p class="text-justify">
                                <?php echo e(str_limit(strip_tags($HomeTopic->$details), $limit = 770, $end = '...')); ?> <a
                                        href="<?php echo e(url("topic/about")); ?>"><?php echo e(trans('frontLang.readMore')); ?></a>
                            </p>
                            <br>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>

                <?php if(count($HomePartners)>0): ?>
                    <div class="col-lg-4 recommended">
                        <h3><?php echo e(trans('frontLang.partners')); ?></h3>
                        <div id="myCarousel" class="carousel slide">
                            <ol class="carousel-indicators">
                                <li data-target="#myCarousel" data-slide-to="0"
                                    class="active"></li>
                                <?php
                                $i = 0;
                                $ii2 = 0;
                                ?>

                                <?php $__currentLoopData = $HomePartners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $HomePartner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    if($ii2 == 4){
                                    $ii2 = 0;
                                    $i++;
                                    ?>
                                    <li data-target="#myCarousel" data-slide-to="<?php echo e($i); ?>"
                                        class=""></li>
                                    <?php
                                    }
                                    $ii2++;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                            <!-- Carousel items -->
                            <div class="carousel-inner">
                                <?php
                                $ii = 0;
                                $ii2 = 0;
                                $title_var = "title_" . trans('backLang.boxCode');
                                $title_var2 = "title_" . trans('backLang.boxCodeOther');
                                $details_var = "details_" . trans('backLang.boxCode');
                                $details_var2 = "details_" . trans('backLang.boxCodeOther');
                                $slug_var = "seo_url_slug_" . trans('backLang.boxCode');
                                $slug_var2 = "seo_url_slug_" . trans('backLang.boxCodeOther');
                                $section_url = "";
                                ?>
                                <div class="item <?php echo e(($ii==0)? "active":""); ?>">
                                    <div class="row">
                                        <?php $__currentLoopData = $HomePartners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $HomePartner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                            if ($HomePartner->$title_var != "") {
                                                $title = $HomePartner->$title_var;
                                            } else {
                                                $title = $HomePartner->$title_var2;
                                            }
                                            if ($HomePartner->webmasterSection->$slug_var != "" && Helper::GeneralWebmasterSettings("links_status")) {
                                                if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
                                                    $section_url = url(trans('backLang.code') . "/" . $HomePartner->webmasterSection->$slug_var);
                                                } else {
                                                    $section_url = url($HomePartner->webmasterSection->$slug_var);
                                                }
                                            } else {
                                                if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
                                                    $section_url = url(trans('backLang.code') . "/" . $HomePartner->webmasterSection->name);
                                                } else {
                                                    $section_url = url($HomePartner->webmasterSection->name);
                                                }
                                            }
                                            if($ii2 == 4){
                                            $ii2 = 0;
                                            ?>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="row">

                                        <?php

                                        $ii++;
                                        }
                                        ?>

                                        <div class="col-lg-6 col-xs-6">
                                            <div class="thumbnail">
                                                <img src="<?php echo e(URL::to('uploads/topics/'.$HomePartner->photo_file)); ?>"
                                                     data-placement="bottom" title="<?php echo e($title); ?>"
                                                     alt="<?php echo e($title); ?>">
                                            </div>
                                        </div>

                                        <?php
                                        $ii2++;
                                        ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>