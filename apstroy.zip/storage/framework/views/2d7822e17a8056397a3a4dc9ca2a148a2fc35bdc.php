<div class="col-lg-3">
    <aside class="right-sidebar">


        <?php if(count($Categories)>0): ?>
            <?php
            $category_title_var = "title_" . trans('backLang.boxCode');
            $slug_var = "seo_url_slug_" . trans('backLang.boxCode');
            $slug_var2 = "seo_url_slug_" . trans('backLang.boxCodeOther');
            ?>
            <div class="widget">
                
                <ul class="list-group">
                    <?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $active_cat = ""; ?>
                        <?php if($CurrentCategory!="none"): ?>
                            <?php if(!empty($CurrentCategory)): ?>
                                <?php if($Category->id == $CurrentCategory->id): ?>
                                    <?php $active_cat = "class=active"; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php
                        $ccount = $category_and_topics_count[$Category->id];
                        if ($Category->$slug_var != "" && Helper::GeneralWebmasterSettings("links_status")) {
                            if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
                                $Category_link_url = url(trans('backLang.code') . "/" . $Category->$slug_var);
                            } else {
                                $Category_link_url = url($Category->$slug_var);
                            }
                        } else {
                            if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
                                $Category_link_url = route('FrontendTopicsByCatWithLang', ["lang" => trans('backLang.code'), "section" => $Category->webmasterSection->name, "cat" => $Category->id]);
                            } else {
                                $Category_link_url = route('FrontendTopicsByCat', ["section" => $Category->webmasterSection->name, "cat" => $Category->id]);
                            }
                        }
                        ?>
                        <li class="list-group-item">

                            <a <?php echo e($active_cat); ?> href="<?php echo e($Category_link_url); ?>">
                                <?php if($Category->icon !==""): ?>
                                    <i class="fa <?php echo e($Category->icon); ?>"></i> &nbsp;
                                <?php endif; ?>
                                <?php echo e($Category->$category_title_var); ?><span
                                        class="badge"><?php echo e($ccount); ?></span></a></li>
                        <?php $__currentLoopData = $Category->fatherSections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MnuCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $active_cat = ""; ?>
                            <?php if($CurrentCategory!="none"): ?>
                                <?php if(!empty($CurrentCategory)): ?>
                                    <?php if($MnuCategory->id == $CurrentCategory->id): ?>
                                        <?php $active_cat = "class=active"; ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php
                            $ccount = $category_and_topics_count[$MnuCategory->id];
                            if ($MnuCategory->$slug_var != "" && Helper::GeneralWebmasterSettings("links_status")) {
                                if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
                                    $SubCategory_link_url = url(trans('backLang.code') . "/" . $MnuCategory->$slug_var);
                                } else {
                                    $SubCategory_link_url = url($MnuCategory->$slug_var);
                                }
                            } else {
                                if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
                                    $SubCategory_link_url = route('FrontendTopicsByCatWithLang', ["lang" => trans('backLang.code'), "section" => $MnuCategory->webmasterSection->name, "cat" => $MnuCategory->id]);
                                } else {
                                    $SubCategory_link_url = route('FrontendTopicsByCat', ["section" => $MnuCategory->webmasterSection->name, "cat" => $MnuCategory->id]);
                                }
                            }
                            ?>
                            <li class="list-group-item">
                                <a <?php echo e($active_cat); ?>  href="<?php echo e($SubCategory_link_url); ?>">
                                    <?php if($MnuCategory->icon !==""): ?>
                                        <i class="fa <?php echo e($MnuCategory->icon); ?>"></i> &nbsp;
                                    <?php endif; ?>
                                    <?php echo e($MnuCategory->$category_title_var); ?><span
                                            class="badge"><?php echo e($ccount); ?></span></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

        <?php endif; ?>

        
            
            
            
                
                
                    
                
            

            
        



        
            <?php
//            $side_title_var = "title_" . trans('backLang.boxCode');
//            $side_title_var2 = "title_" . trans('backLang.boxCodeOther');
//            $slug_var = "seo_url_slug_" . trans('backLang.boxCode');
//            $slug_var2 = "seo_url_slug_" . trans('backLang.boxCodeOther');
            ?>
            
                

                
                    <?php
//                    if ($TopicMostViewed->$side_title_var != "") {
//                        $side_title = $TopicMostViewed->$side_title_var;
//                    } else {
//                        $side_title = $TopicMostViewed->$side_title_var2;
//                    }
//                    if ($TopicMostViewed->$slug_var != "" && Helper::GeneralWebmasterSettings("links_status")) {
//                        if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
//                            $topic_link_url = url(trans('backLang.code') . "/" . $TopicMostViewed->$slug_var);
//                        } else {
//                            $topic_link_url = url($TopicMostViewed->$slug_var);
//                        }
//                    } else {
//                        if (trans('backLang.code') != env('DEFAULT_LANGUAGE')) {
//                            $topic_link_url = route('FrontendTopicByLang', ["lang" => trans('backLang.code'), "section" => $TopicMostViewed->webmasterSection->name, "id" => $TopicMostViewed->id]);
//                        } else {
//                            $topic_link_url = route('FrontendTopic', ["section" => $TopicMostViewed->webmasterSection->name, "id" => $TopicMostViewed->id]);
//                        }
//                    }
                    ?>
                    
                        <?php
//                        $detal_w1 = 12;
//                        $detal_w2 = 12;
                        ?>
                        
                            <?php
//                            $detal_w1 = 8;
//                            $detal_w2 = 7;
                            ?>
                            
                                
                                    
                                         
                                
                            
                        
                            <?php
//                            $detal_w1 = 8;
//                            $detal_w2 = 7;
                            ?>
                            
                                
                                    
                                        <?php
//                                        $Youtube_id = Helper::Get_youtube_video_id($TopicMostViewed->video_file);
                                        ?>
                                        
                                            
                                                 
                                        
                                    
                                        <?php
//                                        $Vimeo_id = Helper::Get_vimeo_video_id($TopicMostViewed->video_file);
                                        ?>
                                        
                                            <?php
//                                            $hash = unserialize(file_get_contents("http://vimeo.com/api/v2/video/$Vimeo_id.php"));
                                            ?>

                                            
                                                 
                                        
                                    
                                
                            
                        

                        
                            
                        
                    
                
            
        

            <?php
            // View side banners
            $BannersSettingsId = 3; // You can get settings ID from Webmaster >> Banners settings
            ?>
            <?php echo $__env->make('frontEnd.includes.banners', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </aside>
</div>