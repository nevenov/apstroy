<!-- Header Starts -->
<header>
<div class="navbar-wrapper">

    <div class="navbar-inverse" role="navigation">
        <div class="container">

            <div class="pull-left">

                <?php if(Helper::GeneralWebmasterSettings("dashboard_link_status")): ?>
                    <span class="lang">
                                <a href="<?php echo e(route("adminHome")); ?>"><i
                                            class="fa fa-cog"></i> <?php echo e(trans('frontLang.dashboard')); ?>

                                </a>
                            </span>
                <?php endif; ?>
                
                    <span class="lang">
                        
                        <a href="<?php echo e(URL::to('lang/ar')); ?>"><?php echo e(str_replace("[ ","",str_replace(" ]","",strip_tags(trans('backLang.arabicBox'))))); ?></a>
                        <a href="<?php echo e(URL::to('lang/ru')); ?>"><?php echo e(str_replace("[ ","",str_replace(" ]","",strip_tags(trans('backLang.russianBox'))))); ?></a>
                        <a href="<?php echo e(URL::to('lang/it')); ?>"><?php echo e(str_replace("[ ","",str_replace(" ]","",strip_tags(trans('backLang.italianBox'))))); ?></a>
                        <a href="<?php echo e(URL::to('lang/en')); ?>"><?php echo e(str_replace("[ ","",str_replace(" ]","",strip_tags(trans('backLang.englishBox'))))); ?></a>
                        

                        

                    </span>
                


            </div>
            <div class="navbar-header">


                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                        data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

            </div>


            <!-- Nav Starts -->
        <?php echo $__env->make('frontEnd.includes.menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- #Nav Ends -->

        </div>
    </div>

</div>
<!-- #Header Starts -->


<div class="container">

    <!-- Header Starts -->
    <div class="header">
        <a href="<?php echo e(route("Home")); ?>">
            <?php if(Helper::GeneralSiteSettings("style_logo_" . trans('backLang.boxCode')) !=""): ?>
                <img alt=""
                     src="<?php echo e(URL::to('uploads/settings/'.Helper::GeneralSiteSettings("style_logo_" . trans('backLang.boxCode')))); ?>">
            <?php else: ?>
                <img alt="" src="<?php echo e(URL::to('uploads/settings/nologo.png')); ?>">
            <?php endif; ?>

        </a>

        <?php echo $__env->make('frontEnd.includes.menu2', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="pull-right head-contacts">
            <?php if(Helper::GeneralSiteSettings("contact_t3") !=""): ?>
                <i class="fa fa-phone"></i>  <?php echo trans('frontLang.callUs'); ?>:
                <div>
                    <a
                            href="tel:<?php echo e(Helper::GeneralSiteSettings("contact_t5")); ?>"><h3
                                style="direction: ltr"><?php echo e(Helper::GeneralSiteSettings("contact_t5")); ?></h3></a>
                </div>
            <?php endif; ?>
            <?php if(Helper::GeneralSiteSettings("contact_t6") !=""): ?>
                <div>
                    <span class="top-email"><a
                                href="mailto:<?php echo e(Helper::GeneralSiteSettings("contact_t6")); ?>"><?php echo e(Helper::GeneralSiteSettings("contact_t6")); ?></a>
                    </span>
                </div>
            <?php endif; ?>
        </div>

    </div>
    <!-- #Header Starts -->
</div>
</header>